import React from "react";
import "./begin.css"
 function Begin(){
    return(
        <div className="bacg">
        <div className="ana">
        <div className="sub-begin">
<h1>Python for Beginners</h1>
<i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>
            
<p>The Python basics free course cover basic and advanced concepts  in Python. You will learn about data , </p><br></br>
<p>variables,lists, tuples,dictionaries, decision-making statements, and loops.Learn about user-defined functions</p><br></br>
<p>object-oriented programming, threading, and python scripting.By the end of this Python free course </p><br></br>
<h4>17306 Ratings </h4>

<h5>52707 Learns</h5>
</div>
<div className="begin-skill">
    <h2>Skills you will gain</h2>
    <p>Core python</p>
    <p>Web frameworks</p>
    <p>Multiprocess architecture</p>
    <p>Serverside templating language</p>
    <p>User authorization and authentication</p>
    



        </div>
        <div className="begin-lear">
            <h2>Who should learn</h2>
            <p id="asd">Aspiring software Developers</p>
            <p id="datsc">Data scientists</p>
            <p id="datan">Data analysts</p>
            <p id="aien">AI engineers</p>
            <p id="proen">Programming enthusiasts</p>
            
        </div>
        <div className="projct">
          <h2>Industry Project</h2>
          <div className="container1">
            <div className="sub-projc">
              <h5>Project 1</h5>
              <h3>Persons Succesmaker</h3>
              <p>Step into shoes of the VP of Product at</p>
              <p>Pearson, to transform the product </p>
              <p>development processes to brtter meet the </p>
              <p>needs of customers in the education</p>
              <p>market</p>
              <img src="https://mma.prnewswire.com/media/617186/Pearson_Logo.jpg?p=twitter"></img>

            </div>
            <div className="sub-projc">
              <h5>Project 2</h5>
              <h3>Demand Forecast for walmart</h3>
              <p>Predict store sales and demand,factoring </p>
              <p>economic conditions for the retail gaint</p>
              <p>Walmart's stores across the United States</p>
              <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZkAAAB7CAMAAACRgA3BAAAA81BMVEX///8iHx//mQAAAAAeGxv/lgAQCwvy8vIcGRkXExP/lQDEw8MdGhrIx8fj4+PY2NiNjIxgXl68u7soJSU4NjYVERHQ0NAJAADv7+/5+flNS0vi4uJ2dXVGRETq6uqZmJhqaGiFhIQuKyuura2ioaFSUFA1MjKqqalCQED/+/X/9OR+fHxcWlpmZGSLiopwb2//6dD/zo7/2KL/t2D/oAD/79T/r0b/s1P/+u//5sX/0JH/u2r/7tr/rTj/xnv/16H/4Lb/pif/6MP/unX/vXv/pTr/qUj/y4P/oir/u17/qC//skH/5b3/tk//xHX/uWr/16wpTJa5AAAWLUlEQVR4nO1d6XravBIGbITNZgIYs+8Q1gQSSkL29GtPm7Rpc/9Xc2xWe2Zkmy0kbedHn6fElkZ6NaPZJHs8FKVzqXipW+41so1euVJPKUXyMZcUiOYURckVM05PpNdrt6ikarF8v5fNNo5OY7WUsub7W1IxN2U6t9XceJaDjwacnzyu9JqawFRZCofDkqwyIZzN13Ob9Zs5PjlqVb1iIlkol1LUE0W9P/2JcCLZ6NajbtvN1fONhKAxWZpxyTQt0ejWnIe3EwrET/KNZNUreavJxmksvnm38dhRoSqGvdXWkT33xXhBY0wSvVaSdHhaNf7qyJ02m8kFNRuh1e9Mn7yw3pwo6rMnFEJAcDKpnt7f9AmvqPeiZeETZHf1pL5yIJfT93shvuQE8oJ7OuVOU7GWFZjR/ZRpo1cmZI/tREc5Mk/PUWTZUslrrK1pO2GZMS2v8FivFzTJyyFJyJY472V6WlhckSzPl36pyUAbrGuZuGhelq1PyKzM425BuZOmFuZxKbNenPdiTeC9RZDAGWyglBXwHElC4YQLZbrBzNOjeueLL9IQwOJiiRi1MDM1L+PiMpvXZIh4T+cWDFmoGb8Wj4gJZAnTxNe8Ku5FlUt2YlOMMQZF2kIya3A0b57ojd9MmRxprcqZI4kl6hxscnB6ZlNQF2TUiqhl8cKMlu1HPOueXEkQGc1AJtBgVBNya9l1iZFLX9QqfGBSBc2JSa/apMVme2SKpwJXWr2i0KeXBI1MXSWnW03CRkJNV3yzPLEwKGQCRyQw+pCrgQUwvJWgdXlSU5LwOsMkCfW9IBOp2rcgy+SSIJE55q0wuWWFJu61VWSmZrvukIlxgDHAnc57jV4zswY4Sr4EFTOHRJmCZltknOcoLFL9UsgoXu5I2JGlU5EvpfBFPGsEMhGb3ZYZyi6XsOlRVEkD+4SLNmpAIHbELZGpyc5zJFJrikAmcGQj++YZTlVdSozRuRyBXRPINGx6FuWAJ3NqO01qmVCa69hWUgGbsdshE3EBjDG2mhtkbIcSbi7dukDLjfZe8px1RiZu26AW80Qclj/DQpOqulNl8wZiu0VGabpbvMTCxcgEqrYoa0ve+XsCSSrc5yAyrF62RSacLNrJ1LSPUzSxjXUmVh8ecjm3QSZTcPuylISBDIxM3X7CxepiOYSJxaj7pJru6FIvqqfAdILIyKcOq1su2/9dJwbn9ZhSAIbbz+ESa/y1kFHzlndL5FyK1DjVPJgehEyo4SB/2lxjlDHHspA8jdVL3YZGcCQmwKqAyHgdlaOz9tSAOktn0WhEVSt0S/VSvkD4bF65B03v7jqqQbAohggKWHlFJkjVhEB0LYCtBiIjd52WyNwGUNCQJbkfSk/HFVC6EsYXGj4ImR0QA/ZnHE2rnMgrAYPLTCByhMcqJqE3HRdkiSKqezlrMUGw8lWTFaWYLkZrPQnuGVLLqkghMs40F1gkqFLSDHo8iXYrBnwaLjJimFKU1kdIjaD3AQIBPTg3rGGe+RJeumg7zBz3sgQ1khRblsUXR24hKy9tvziyDYBjwUVGlGQsiwZJWaP1NBxzWLQ6odg1kQpukJHURDOZrHptPEpZTlSrCZEKBoDNrIgU5pHVLC4hqdGw1xdIYwooLdy9de1h78MSCknJoIFw08IbBxlJrmaPGkmRUG1i1YBAAb2KCeikIf0sJlwgo7ZKSsaI81d4PmVYK9eUQCAXOqniFS/3LCoBBjN08w5wWYArVyWiFRQR249csOiyEBQZKWlp4Riybw1U08iwxiwfE8oTf9YMfRAHf8ADSqEXJevmSiGjNpZmQoRWWHI1vmgm10TQSA3L1EO7SjiGXNbh9MlHLlI9+viJiC9YnEhkVOvfA9DWklrmP0cpZFh+Mb4M4bRMd3LojAsoYJruweUoW58hkJF7plUXpzZZybxDR1vwEalgNgAzYOzhFpr1IlrYBTfI5AgPEuRm0MzKZdAyCk9aQpsUMhZ1iW01zVh4XWuUUPRi7pEjIFvNHkpmIrYNGGTZoJHvFbaGXBvWvQjaBzqloaUiJt0gUyZ0WcP6IuKNQYFNwwlQzfwRyEhJs65Gm+jMhkjnE0zQlslbDUc1cCRRtjobGBngQUec9lhPBjYBkEk1EpqwSM3qI8MBywC0ZMSEC2SQDjT2b6tGyPShMtNQw1CdiWYbgEAGpAtQyGSGbEZRIrXYaaOqCYImoMSNh4jegNgQRkYAFisOeQnA24AbOEDGk9a5rJ/0C16dSU1AXqTOBJxA0euMTK6JrRO4hSlNwLx1F6FnyOzyYWSkrNXjgXu9V7ZGIHS/MkSWgSCPxwkZMQGaQcsuDEdXUeEDvGqdohKnElSZU7SVOyOTJNwgGLFD00YES0NwhsytYGRgCzm4cmUcNiRpbWSQWYTWFAhL6X1As5iLDIeIvIIjMoQuk5DSQPszkftBcfCwya7GyECFUYShJ7oKAdPayKBVhfIRGtxE4RPhguvasxltIDMhItwmoCB+AmpihosocgWoFU3uOkIG+oOeANxopLK7Qa+NDHK/Q+gJqJCgzpDWRcazPjJJbDBrUJY9HjSvVSzNhGOxGiC2uvvg9Qw0XiX4BKJAMarvvGjMjjIDE3sp+IQElybEbg1kMoFiTlHiOLTugAzl/PdQVgezniWq/tAUmWJnCBmcsK/AwjwbZIqpeL3U7TeSXg0Hup2QkaBEoABFAuYsYXROyrpBJhqJ12P5frYpCkR9nj0ycSIyIeBUag15kRg9YjMyeVwIGZgmwH6JdASfMKiYi1caCaOg2ahtpgMrTlYz3CMhMmJ1S2QyUaV2WhBtubRHpqgSdYpEfQV2GagaBfzU0RI/hIyGTAj4OoFM9LhSkAVc2Qy63RqZJtxFkTazQ0ap51uahiqbIdkik8e6TD0i5hxJA8pZGoRTKasSEYQMUuWOyKRDDa9qX0E7IydkErBrhAxKa7lHJlorhBmx4DHZIUOk4lGudkrIGCdj2Mj+FleRBGw1r4lM5rggwEwDh9ZGRtkZMtFSldhRaLJBJkeMFFny07HhQDOFDC5TkpYjRMigTdYWmUwtSVc6ULQHZJDVTCJTLCVsEnGQbM5SEelplazZxfYwEU0lAgUmb3I7ZIqn/PMZmA6FjFLQ1qk54yNDlMJIVfLkTREZ41sjg80fG2RSrbVKzg6EzHFinYpFG2RSRLk3Eb6eTiuq2SGRQa60yQDfBpk4Z8iiGJZkGZeNHgaZOqfeXBQlg0v8Rx4y6SweLhGmnE0rymK7RWaJ9BbIRBJk0pHJ1WQr2+uXsxCagyBTJ1ePzKRqstDQuUwiaHjIwLi20UyW87BLmcFlLKtEyObIUCW7ItN6pXgqOuUXWZiHQAZrcqPGI9yvx+dHr/Nu42ZES6KXPHzgofYZ0jYjZGY5B5sjQxQMq4mKsvK61o5o7gEZBYcfRbVVKi65dB1rzqGaA3285FEog9IYGcrTJJDZ3gLAdoooVCzh1PeATB9xKSVKZpfdNTKn2Nhh/AAi4c/Asm6K/V0ggxOuoghcrneADB653LSOzy0yxDG8cMImS4cD7VTcjOBvhQzo0S0yOH4Ek/jvAJkMKiyWYAsZfDKEQkZBiTAdGe5BdQ8RNyNjzQhvc3RmM2QCaDywavk9IBNC0ynBSLo7ZKhjeAxny2wmjc7PoLiZOaK5GTLI7iLO0a1dO7NzZJBgo7QgNecEMjGiwqhgezkJlgZ35UX9ZaubIYPrGgiXC2bc3hyZAFJBOF2PSlgpZHAhsBeUJOJXcBafQMY2c7YRMjl0BgPWdXioGs03Rgb5ceEkWufpFgpV4ApbwvnnXWOyIFSjOCsHB4Rr+VZ2+GbIKHj/x7yhbt8aGbzRYcu1iLd29AyR+ZcaTnUcKD+HLCSjQNSuQmMjZFCWO5yEbxEBClgLv29k0NIg0sL4LASDc44PKOlUT0VSqZSSK/J2G6QxiPCMAkND5lrIzZAhLA/cbQKOBhzn2jsyaAshklxojXkFgEyRcP71eRYEgUmJZKNfKYUodFBSjJiiFLp3zPTMZsigYJPcQ91i3wwcotw3MgEU79XwfQjYNIM7Jn1F0Zwh4/41HaRmNwUjqdgD0lDnyGg2n6zeDBmkJ+BJP53wqWIgz/tGBm/u+KRfERe1A/hIXQZJZKxwYp04dFzSqyHDEC0Ls5WwGTJ9OOv4/AwyG5GztR9kVl0UETLsBHJJZCmtxcH48BSHJKa1LIX3qGm00eBTpH1TAzuSGa8AdS11Q4z1xp59I4NlRoLHNNLEvIdbUZsO7EgSzDcLQuaxMw7L5a3qfkf7DFLhNSphZd2N9o1MBu0zXg14e+QtDJb5sb9wBQ1QM8X68TYHjgvCB8SqeU3syDbTBdGyHKP05TWWMtN9I4NtM6jOqKp+4/SYKfa41n1CXkttNhI3UbIENdEkWiNxO/JnwErLce7hkc1Hj/eODDoYpfsL5i5CnIPt5hlaQ5lNSV0dk0XHW7zM7Oli08J6wngzZIgqEpGt/MhUlndFijkivXdkiCvn5MJq9HGRt7mb4vvrIiMVVnKBCzrZStnV8AEba7R+w7gZPIRovOmtTC8kD+QqNmVEphjF3pHBuVzjOoHajEulx68sDa/OumyDjAdXSrBsPJ3JBNKpPupdBEdwN4w1Y0VhdJsox+qxI9nuNlppdVxv78ikKckVtWa3VKpkNbutXV2aKlshQyh9SUiW8/0WdVcTCB1tmJ/hXNylO8TMwZhZGSh7RyZDXPRltKLqXDp4KcsCv62QQYfCDArLKnWDo+WSii2QQVdPuKaVNt07MtQVJG65XJhYWyHjiXrdXgEbrsKhbVoHQC9H1B/6RV61v39kiHvnMFHX27BlM9sho68NlxcSo5OQGyNDlSzA3uQ68uRU09LYPzJu7p2VqnFUx8FWd21BDoyvUAiCsSylabgZnpMCyHDUPiIV5yc2Rca5yzA7RiY965mm9g2QyfScRFtOpDwpYLKYryEztS+pqvFNlVJIKc4omoqXTrNNLzMdAYHIUIfUMGlEAefGyHh69l1KCSMZYnV8NEvN1Rsg48kRR8TNpE6/N2C5f06UzSUNi/ZFJhS6tRRVVxM57iaFBTgIGVwOgUhUqZrnzZHJcd3J6ZDn53Biq/ZFVrGYH2+BjC4PdtCwWdIgYyrllKxXKs3aV+VmN2Xzcaeikm/K0+nAyOjQ2JsBnA9abI6MJ9rjGmii1p8H5zJLaRYlwMCbIOOJ4Ovplg9rsflSKRYWD8lNa0rcaJ+JeftCmelAa3mJGfEnnOCM237WgrU4R3A2R8ZTPKWdF5FJq4/BZLKz1yVUhPc2yHiUJO35Siy5mu/U/JIfGRqvFYGxvOLqmsCMcioz4hpOnYUe18uT1T7nu01bnTnz1LL4NKCoJSrmaHZgqirkFi71Ah+ZkJqwIisKbE4ZlRvCAJ7ax0s2U6/i04CSULB8SkhpGetaQ9OUqZXWuGNIKXGEK94gj03K6hHvnIenCL66IOHLjmCCxxx5S9eS2vTOA4OMT7oxVo2BFgJlgWlUhWKdWYgo4Ypp1ieQ0Z/JC5YncEbXoFxJMj4xNvtyWtj4xJhWgJ8YU7IaEwhcd0TpUNZ6rfr0S2eNlE2HdTB4LI3ppOURDaiUXL3bK1QTiWqz1ShXjqnvjR136U9dFUMmilBSHbU8Qe3BiuUJ7kBTpXyjNeOyd3pSI9ZJJtZ13k22oWg9XzA+TMiMj88J1Wy35vDBSOfp8aTMjxDil44qs49EvtHnDzcj4wIg4xOUaVe7xj4oE1Uix6WT7kmptuXXRv8Rj9qX7Xb70Ez8IzNdfj4bfvnv9/nF+fn57y/frh5uDs3RP/J0BlcvvqBO/iVN/3d7/w+dA1L77L9nf9DvI8gf9N11Ds3f30qDXz5dUihYZhQcHZrD7WkyPDs0C2vT5NoX5KMyg+bToZnclgajoP/x4UNZNTfndtKyQObjrTdAg6lePp8cmg/39DpykpcpMleH5nNbal8b4/T7zz+KOXNnwmVpjhnWGUBmeGhGt6bLi+Bsyxx+CGzawSUavsfbl6fru6FOd9cXz7r9/EfJjD7Wb7Pl5v8YpubF1/9dXH87m3TaVqe/3f50930lOB9/nzFouBjNaPgBsLnk/6lzsYQm+PBmDO2TXn3zEfm/f7MZ+PunzkpmPoRudqbPj4vFFvR9+cBjao+X4zg0K7uiznilB74/fQCdxqHrxTD+gBjAnNp3q91Tt6F/fijfc0ULZPxPh+Zkh7TcbKZ22tf7j4hN+2k+huD9oVnZJQ1uzU6cbqgNDs2RCxpcvYzvl1ZL+3axuj4C7+6pc25xpP2j8/ceUHs4H+meZ/B28f/2aM7614+7VdL0OrJi864FZ3A1mudnls7LzVzq/f8dkrG90GAMwoXB0fm73HHaZ+ffl6wuHf6zIPjhT6JvPhAb9Af9T5P3pRw6EyNxZuJxsdEsYgDB97iYtqYJjrL7/c93nw/N15Im38aWxJnft5CQ9tf5Lz8OyuDeqH0FxcZYhUHf9eTw0YHO4NsoaM3++78u05eTxU8fKN20Hk2eqeRU0P/432GNtZ9AWqa69tdK097Po+bP70v57pSGI05VSvDxanCIoGf75uHJF0S1MsHnn6Zn5iEm/8fPmtnQzZiuGDJKhsZfHt4YnM/D8xHBjz94bpaORaQ5+AeLjEGfx7w6CCOnOPo1uXkLeNqdwf0PPxaWKR//s+4nVzNNF/yTYmYkXV7Z1Q7peu1ieLbf1dn+efX71scR3qB/CJbGYim9X+d4Z9S5prebpez4/b6Xq0Fn98LT7tw8/Hqc9UD37buGq2Jumfm/7Jyb90iTJ86KXU2Rrtkuvly97q7yrj15Hf5+JrZ7c6e32DCeW2a+w9v2b0OTC8K7oYTHd3t9NbjpXG5sV7cvdUEZvjz6bERl3t3XB/z65UyZ/QHlTG6p/fPWSW4WE2ZUGo3/G96/fv60loK7/PTz9X54Ph5xtnogL6NXqvXB9E3/+EMXMqxLP8fOcmPCx3j2+/fbl6e7q4dBZ0qXOrUXZPxn+uvg4f7b9cvt99mEu6iJncrLGS2V1zNz5Y91/2lqTy7cyY1lDmcFe0HfaPR4Ox6PLy6M00f6vxfj2+fHkY9TXWnbZvCRlBedLqcP/EW6bEk3T4719/YwWWmjRnxjfnRouv/7z//IILMTfRpSfvibkRFS5TPXNvKxf3TAzJbar2tsODslv+/Zvrb3xnjo8W8xmCma3L294Ph1ceFtLwv6FdSB+QucfzvqnOmC83bg6F19dVFuPfL/3RIzp0/3Y/8W5sAaFAw+Dl3ZwdejX3/rHmOl9s2v531Ljt78919uk0Htzl9pldE0ub/gxYF3AEvQN7766czEPyLpsnM/9u1edIwGX872EMH+y2hy9fvRRbjLLSr6znJ+9VEL3t8btTuDb7dOAWIXkmI08ON+8G/H2DF9eh2ePxpZlQ3wMZI8z7+HO0zy/CMLtTs3k6unx8UlPW7EZBrVHL0MJzf/ROUN6Obhfvjl9/h5Hk9eRTFNNyoFfaPn8fmX4dnPf37IG5ORorwZDB5eh3fXT08vLz9+3N7+GL9Mj/Dfv04GN9vkPz8M/R9ufyBw0BcSzgAAAABJRU5ErkJggg=="></img>
              
            </div>
            <div className="sub-projc">
              <h5>Project 3</h5>
              <h3>PGA Golf is Sunday Made For Tv</h3>
              <p>Analyse a Golf tournment to</p>
              <p>identify if Courses were made easler on </p>
              <p>sunday to telecast low scores or if the </p>
              <p>pressure on the golfers raised their scores</p>
              <p></p>
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnP4dh6b_ydM3PwDRKjxvqNySlu9FwacHrPA&usqp=CAU"></img>

              
            </div>
          </div>


        </div>
        <div className="reviws">
          <h2>What other Learners are saying</h2>
          <div className="container2">

            <div className="sub-revu">
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxhRCoaB3ZF4oPSW78AIjBJZIKS61ZsF7IWxuNHyFIzCmcTzmo0AAXzrh8hbu9XL6-W08&usqp=CAU"></img>
              <h3>Dhanya Krishna </h3>
              <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>
                <p>Fantastic training by my instructors. i highly appreciate them for there</p>
                <p>patience and interpersonal skills. i'm also amazed at their</p>
                <p>methodical teaching and control over the sessions</p>

            </div>
            <div className="sub-revu">
              <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFhUZGBgaHBgYHBoaGhoYGBkYGBoaHBgaGBocIS4lHB4rIRkYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHBISHjQhISs0MTQ0NDQ0NDQ0NDQ0NDQxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MTQ0MTE0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQIDBAUGBwj/xAA/EAABAgMFBAcGBAUEAwAAAAABAAIDESEEMUFRYQUScfAGUoGRobHBEyIyQtHhB2Jy8RSSorLCI0NTgmPi8v/EABkBAQEBAQEBAAAAAAAAAAAAAAABBAIDBf/EACERAQEBAQADAQEAAwEBAAAAAAABAhEDEiExQSJRcWEE/9oADAMBAAIRAxEAPwD7AiIgIiICIiAiIgIiICLzXTHpSywsaL4jw4sbKdG4y4kCpAvNZSPxXafSW0R3H2sV7wa7pcdwZAMEmaE7onflK8H6Atm2bPCE3xmN03gT3C5ch/TqwD/eJ4Mf6hfCv4oAZZAXDsWAWsZTxTiPvEXp/YgPddEecmsM/wCqQV2dOrGXbu88DrFsm9pwGq+GQrdSV3gre0Lj7zhLj5BOK/Qdj6R2SK/cZaIbn9WcieE711V+d9nxGl4ruVmDk1te31X1vZfScNgsLwXhoIMTeEyG/NI30vrgU4nXrUWGyWhsRjXsM2uEwZEU1BqDoVmUUREQEREBERAUKVCoIiIJREUBERAREQEREBYrTHaxjnvIa1rXOcTcGtBJPcCshK+Q/iB0qfEiPszC3cE2TBPvOc2RqMBUf9jNB47pPtl9ttL4zpyJ3WNvDGN+EcaTOpXPZZSK6T7OZrfs2zohuYa5zou5B6MxHC5S7zP2upjV/I8WQZrHJe2PQ6NO4Bcq37Aex27uHWQnLtyU95T01HDj2fdAc0zB7wcisDHLuv2DH9wbjveJlxAJ8ge5a8fY8VjSXMI4hX3h6X/TUDnC4z0Xc2dtN7G/E4YSN2NJLiM3mn7VWRsSlB3BdSubOPrXQnpU1oh2Z1xJa2UyQXFziXkiW7M4L6MCvzrsvabYT2unUaB0gRU1xr5L7X0S2iY0KZM5Urfh4KjvoiKAiIoCIiAiIqIREVEoiLkEREBERAREQeZ6Zbfh2aGWODnPe0loa4NIqACTOYE8gbivlnR/ZwixN94JDazNZnCa9J+KLibQxgHyg/qJoJ1rKSvsyziHDa2WFeJvXHl165+PXw49tdraENouC6NmauU19V0LI9Yf638+Os2GsT4IJnKquIiOcvb48f61jZwSCRUTl2iXPFa9ssDXiRC3t5UiPU07jxG0ujIJLhfoJLkWvYkmVob+3sX0GO4FaMWEDhNc58mo6vjzXycwdw6hfRegHSRzHthO+BxlU3E4gSuXmOk+zdx++BR3JW9+GzN+1sY4TvNRSnkcQtuNe2evn7z66sfdQiBF28xERRRERQFClQqCJJEEoiKAiIgIiICIiqPmHTaCHW44yaw3k3g912Ck/COC3+ksIOtzv0sHc0n1URYFFn8v1r8N5HPYMl0rIxa8KAunZ2AYrN/Wm34zCHRSGlZg6iUXp8cdYgyaxxYclstcBiqviMPzBL+LK5LwtdwXSjNbmFz47CCvN6SuXtqzCIyRv+ixfhhYZW1zj8kN57SWt76+a6MdtDwW7+G9mlFtL5XBjQf1Ek/2havDfnGT/wCifevoKqiLQyiIigIiIIUooQERFRKIi5BERAREQERau0La2E0FwnvODRhUgmp7Crbz7SS28jy/SCHK2tODmNPdvA+QWhte1mEwbom4mQyGq6u2LQyLEs72kbw9o1zSRvAbsxMZTBrqvObetQB0AXjqxoxL+OJE9u472/Wc9Fo2raNpY68tlkadyqyO+M9zWEkgF262lBm68nQZrmGM+M9kMMLXuu958rpzJLjOmimc1dakehsW3o4Mi4kYTXahbdcWzkvDWWI9ry1wNL5iuS9hs3ZxiM38O5ee8yV6Y1bGja9txC503SGElwn22K40cZ5zVdqte17hKgnwktY2Z7GMiuaS0v3cZ0E6NmPE1Xec/HnrV+u7YvaXuidy7djt75hrjvNuniOC8fBeYjHxBDk2HugvZvMdM4bu8Wul6rd2RaXkiZnr9RgVNZv9dY1L+PZxGUdoCu9+HsDdgxH9eIe5rG+pK4zDvQ3k9Q+AXpthvh2ezsaXAkt9o6RHu7w3iXVoAJDWS68Vk+ufNLfjvIqQIzXsa9pm1wDgcwRMFXXuzCIiAiIgKFKhBKKEQSiIoCIiAiIrAXn+moP8OAL/AGjJaETI8l6Bc3pDA34Dvyyd/Ka+E1zudzXWLzUrxdlM3hxwDvGiwW6yb5qFOy2OD3k4NLe2YPp4rcN6yW8kbpPteTi7Oex++3ea4XFsxTsWJsCJvlzGAPPzSINb6k+i96yGHC5T/DtGAXU25uI8fD2OWtm4+8b5CQlwXrtlQQyz0FPstG0necABSd671mhgQ5aLjVunpJMx5K27HD584g+i89abNGhTYWtcw1kWiuU6VwXtoh3XTw8lu+xa8VAKePdk4nkxLevnlkY9wLGsk0mcg0NbPPjqvU7O2W1jAC0T4LtNsjWijQOxYIzpJvfwxnjV3ZNePyu8lyrTHLobmMO60gAyxunPsXVY74uC4+xdlOdGdDJ+bcJvo4391Vc/ZC3lr6pYobWw2NHwhrQOAaAFlUNaAABcKDgFK2z8fOEREBERBCIiAiIglERQEREBERWAsdoh7zHN6zS3vElkRB4GHC3HVmHEODuy7gVULs7Q2RF33PG6W+86c5GUiZSzXFcZLH5M2Ru8e5b8bcOJRVixZ0Wk6NILCy1GfmvLPePStbaG0nw3hrWBzRUgGT+LQaO4TC6TtsSbMGm7Of2zWjamTquY6yvJ07V3J1LeNyxdIYzn7pgFrDP34hALst1owXqWSElwbHYxQuvF1B5rfjWotpeEvP4OhEiLRjvWFtqnisb4y89dr0zGSGZTK7PR6wDfDx8IBcc3PPuz4SNOC5VisT402MIBkTMzlSV8szTtXqdjWKKyZiFt0gGkntJ7Fpxm9jN5dSSzv11ERFpYxERAREQFClFQREQERFyCIiAiIgIiKgvDbXsphvc3CdOBqF7lcfpJZg5m/i0gcQcO9efkz7Zenj166eIiVoufanxJ/wCkxrpX7zi3uIBW9aaXJAfIaLNP8W2/5fjVgC0PkHPYw5Bpd/UStsWC0y3RHZdOcjPy9Vkc8SumtYxQrNT/AEck/UvbaWU9tCiUuIcP6mzWkyPaQ/8A1ITWsOLX73hJdWDHb1ZaqY0akpLn2nfxbnv41g4YKzHTWnEeQVuWIy94q5z2prXrHuOjNl3WF5+ag4Ccz3+S7ZWvYBKFD/S3xAK2VszOR8/V7eqoiLpBERQERFQREQEREBERcgiIgIiICIioLw3SPpYx0c2JjTMfG80kWt3wG8aVXt4jpAr5X07svsrdAtAEhEG679TQWzPFpH8qmvx1n9jM54dx81QiS0or8Qph23B/f9VlvNRsncutZmtN62S1gpILkCLkVR9pXEzY6upXYiQ2SmFzY7wLlqxLac1oWnaAGpySYtp7yRuPeLyZc4K9njbxGS47XPeZu7BgunZvdkvXsnyOJLq9r3vQa3OiQojXGfs40Rg/TRwHZvL0y8X+HLpwYzpfFHefT0XtFoz+Mev0REVQREVBERAREQQiIglERcgiIgIigoJRQXLFEceeKoiO6dy8P+Jtic+zNe3/AGnteQOrVpPZvT7F7Xn9+4rWtlmbEY+G8Ta9pa4ZtcJHwJSq+RWK1bzRO9ZXtBWpa9nvssd8F4Pun3SfnZ8ru6/UFbLDMLHvPK2Y17Rjc1wuJC14sd4+bwH0WyXFJtN6ktjq5lc+b3XuMtKLYgWYZLLTBZoQXV05zmM0GEAlpibrSclmbRcq370Z7YTKueQ1vE4nQX8AVzme1emtTOXv/wAMIbhYQ51N98Rw4b7hPwK9f7Uh0jcbuOOKw7PsTYMJkJgk1jQ0DRoAWS0s90HqmfZitkfPrZBUrEcCObisgKqJRCoVEqERAQooRRERRVkRFHIiguVZ688+SvBYuVXJTTnkKBzTXhxQOfH91jiXT7e4fUq5ux5B+qgjTH1P0QQ4U55xWPnsP2WQ3c6fQqjh4fsivK9ONh+2hb7Gj2rJlsqFwHxs1neNQM189sdoBkvtjm0/c6H0Xyvphsb+HtBewShxJuaBc19N9ulTMfqlgvLyZ+devi1y8axYCsD4CmA+iykrP+Nf6xQoMlsNhAVUNJSISpaScYbTFAEgun0AsHtLQ6MboY3W/rfSfY2f8y4doaTRe42BFbYbGx7mbzoh3924kGRmaEyDQ0XYr18U+s/m1ePdO57yjmzBGi5ew9tQrUwuZRzZB7De0+oOBXWHPctLOq0Ulfd98NUaSDzl9ka28X3+QR2cuaHLVEXnz2KEZrogpz9tEBFIUSQQiSRFEREVJKhzli3pu0F3ZerA15zCOU73DmvoFBfqOQNdUN3Z6BJ6jlw1VE72vln9lUPGflkT6q47OZqhBl+/VQWnz3BUdwPJOasZz7/Nuqq465ZZlQWLeeP/ANLGfv5n6K+9Ks+3u+hXm9vbRc8ezh0b8zpyLgCybRQ0kb0HC290le+IYcI/6QpMTm8ycC6bflm0SC7VlYy3WUscffYQJm8OABa7hukDvXnm7ILj8IvAxPzPGS3dkiLZ6tAAMt5pPuulDmAQGZg96lnVzefXGds0tJpKRII1F4WRliXtHWaHaJub7j6TGE5TyqLqrmRrIWHdIkQse8az/wAbseTOv+uCbGoNjXbEJZLNZS926BxOAGZXnO28jq65HL2ZsH2rwDRgq4y/p4lV6X2pkaIxkNwLGNDZiUt4785aCgXf2rFDG+wg3zbvOmbi4AiYBmTMzXGhWFwIp1evm9bsY9Z/6w+TftXC2NbHWeIIjHAy+JsxJzd1hLTXTwX1ux2lsRoewzaeSDqF8/Zs5xF14/N/xj6L1ezXuYLqVpOl+spXrpzHa58kcKc6/RQDPy8JZqZ+nkqiGnTmZVhUdyoO3x0+qiE/CfMgguBzzwUgo7t8c/uq9/MxmguqTUh3PPFY3FBkRYZjLwRF6hpz4aXI4y5+n6cFUc8Kd+ClxOFTz6tN2aqLMN4lzRXIrcL/APLgsAoc+aU4SWccOd7QoIaTT75O0Vzj2+QVA0Uvwz11VCNMDgOqMygzbugx8xooePMf3LHOt2fVzCtPQXjEdZQcfa8Vzhug7omJ3TcCXUMzTgudZ7LNt5NMD/4/yDRegMCZnIfL5u0VmQbuzM/KQg5jLKOqTUmoODmux4lWNib1JXXboxc3PVdJ0O+ueA6ozR7QMf7esPqqPPRGPYQ9oIIri6c2UmATi1bf8cyIN14kZhocA6jiAa0oNbuC6Psh1ssW4OIy1WIWNouIwJnW4SuB/KFLOupbHNdZSX7mPhLPgs1oishs9mwzcaEgE9WZJAvqrxbO5rJMk1pDjKpcGkTAErhPCaobE7xODus05rjGM5vV35NX40oFkBrI3473/JqVtQbIKTZP4cs3ZuW2yBK8yrkB/uazW21oEveyxb1jovR5uWyxtABDJUGA6svlOq3GMpj/AFZHMaLK1lL8BkcG5LOyGZ/Y5kZ6qKtDpnicdDkthvPesTGmWHdpx0WTnwmgq065Zc4KkQkcnL7LJOXj9VWM2fJ1yVFwZjv9foscU0pPk/dUgRBcT39ufFWjPu5wBUCfPfgeCobjp4hWfKWVRpw8VVn7DTh3qiN46osW7+bwRUXN3jPL6Yq5PZ4aynxGGaxC7T6/bDVS1xpnKnZ9wVAOnOVOBF+S2GHXLLM6LXijM88MaHwWeGTIfX9SKs3CuWWRVXSrXPLqhXrzPqo6de3PRERK+ueWmigjU3/5aK1Z9+eYVpeY81Bia0a4dbrFSGilMvI5rI0enmdVjPHy6pQSW6Dw6oRwPPEaKTjfjnkFYt57VRQA8zxdwWGMJ0lfLzP1VydOrhqcljs7Jmf6bwdDigMhndAlTdlKQn8N16l8IdXPAZt1WUC6uWXVKh7h1s8sgVBjDJXDPLrBZJHxz/NwUulWuePAqCRnnicwVRUMpdhp1fssjW6Z5ZgqGyz8dSFYupfzL7KBIZeWZClvDAc04KHOGeeIzBUjjp4kIJcOOGfBQOGXl9laevlxVCNc8s5+qDWeCCDwzHV4q5cKdnlpwxS0MEjTO7gclhY7XvnmQVRl37hx+5n2+CMPfjzj91RhOc6D608QoDvLjPj3hEYpMy/pUq24NO77oqEP4Tw9FkZ8Te3zciKKpnz8pWxA+EcPQoiishx5+UKImPb6IiqK/wDt5hRDvPOJREBmH/X1WYXc5Iigh318wh9R5oiDXbh2eRUQ7/5fREVGxDw4D1Uu+vkiKC2fOCqce30REFm385pz4FEQOfAKw570RBH28imfOChEGGPj2+RWtEuPb/kiKopC+E84hMv0+oREGgiIqP/Z"></img>
              <h3>vikas </h3>
              <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>
                <p>The instructor was very knowledgeable and provided live project</p>
                <p>cases.making the sessions more enjoyable.The topics were made</p>
                <p>easy-to-understand with real-life examples.</p>
                {/* <p></p>
                <p></p> */}
                

              
            </div>
          </div>
        </div>
        </div>
        </div>

    )
    
 }
 export default Begin;