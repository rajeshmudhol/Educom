import React from "react";
import "./machin.css"

function Machin(){
    return(
        <div className="mach">
        <div className="ana">
        <div className="sub-mach">
<h1>Machine Learning</h1>
<i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>
            
<p>The Machine learning basics program is designed to offer a solid foundation & work-ready skills for</p><br></br>
<p>machine learning engineers.data scientists,and artificial intelligence professionals.Gain hands-on</p><br></br>
<p>experience in data preprocessing. time series.text mining.and supervised learning.The program is ideal for anyone looking to learn </p><br></br>
<h4>17306 Ratings </h4>

<h5>52707 Learns</h5>
</div>
<div className="mach-skill">
    <h2>Skills you will gain</h2>
    <p>Supervised abd unsupervised learning</p>
    <p>Time series modeling</p>
    <p>Linear and logistic regression</p>
    <p>Kernel SVM</p>
    <p>Naive Bayes</p>
    <p>Decision tree</p>
    <p>Random forest classifiers</p>
    <p>Boosting and Bagging techniques</p>
<p>Deep Learning fundamentals</p>


        </div>
        <div className="mach-lear">
            <h2>Who should learn</h2>
            <p id="mang">Analytics Managers</p>
            <p id="mana">Business Analysts</p>
            <p id="mia">information Architects</p>
            <p id="mde">Developers</p>
            {/* <p id="bi"></p>
            <p id="proc"></p>
            <p id="stud"></p> */}
        </div>
        <div className="mprojct">
          <h2>Industry Project</h2>
          <div className="container8">
            <div className="machi-projc">
              <h5>Project 1</h5>
              <h3>Ecommerce</h3>
              <p>Develop a Shopping app for an e-commerce</p>
              <p>Company using python</p>
              
              {/* <img src="https://mma.prnewswire.com/media/617186/Pearson_Logo.jpg?p=twitter"></img> */}

            </div>
            <div className="machi-projc">
              <h5>Project 2</h5>
              <h3>Food service</h3>
              <p>use data science techniques, like time series </p>
              <p>forecasting, to help  data analytics company</p>
              <p>forecast demand  different restaurant items.</p>
              
              
            </div>
            <div className="machi-projc">
              <h5>Project 3</h5>
              <h3>Retail</h3>
              <p>Use exploratory data analysis and statistical</p>
              <p>techniques to understand the factors </p>
              <p> retail firm's customer acquistion </p>
              
              <p></p>
              {/* <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnP4dh6b_ydM3PwDRKjxvqNySlu9FwacHrPA&usqp=CAU"></img> */}

              
            </div>
          </div>


        </div>
        <div className="reviws">
          <h2>What other Learners are saying</h2>
          <div className="container2">

            <div className="sub-revu">
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxhRCoaB3ZF4oPSW78AIjBJZIKS61ZsF7IWxuNHyFIzCmcTzmo0AAXzrh8hbu9XL6-W08&usqp=CAU"></img>
              <h3>Dhanya Krishna </h3>
              <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>
                <p>Fantastic training by my instructors. i highly appreciate them for there</p>
                <p>patience and interpersonal skills. i'm also amazed at their</p>
                <p>methodical teaching and control over the sessions</p>

            </div>
            <div className="sub-revu">
              <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFhUZGBgaHBgYHBoaGhoYGBkYGBoaHBgaGBocIS4lHB4rIRkYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHBISHjQhISs0MTQ0NDQ0NDQ0NDQ0NDQxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MTQ0MTE0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQIDBAUGBwj/xAA/EAABAgMFBAcGBAUEAwAAAAABAAIDESEEMUFRYQUScfAGUoGRobHBEyIyQtHhB2Jy8RSSorLCI0NTgmPi8v/EABkBAQEBAQEBAAAAAAAAAAAAAAABBAIDBf/EACERAQEBAQADAQEAAwEBAAAAAAABAhEDEiExQSJRcWEE/9oADAMBAAIRAxEAPwD7AiIgIiICIiAiIgIiICLzXTHpSywsaL4jw4sbKdG4y4kCpAvNZSPxXafSW0R3H2sV7wa7pcdwZAMEmaE7onflK8H6Atm2bPCE3xmN03gT3C5ch/TqwD/eJ4Mf6hfCv4oAZZAXDsWAWsZTxTiPvEXp/YgPddEecmsM/wCqQV2dOrGXbu88DrFsm9pwGq+GQrdSV3gre0Lj7zhLj5BOK/Qdj6R2SK/cZaIbn9WcieE711V+d9nxGl4ruVmDk1te31X1vZfScNgsLwXhoIMTeEyG/NI30vrgU4nXrUWGyWhsRjXsM2uEwZEU1BqDoVmUUREQEREBERAUKVCoIiIJREUBERAREQEREBYrTHaxjnvIa1rXOcTcGtBJPcCshK+Q/iB0qfEiPszC3cE2TBPvOc2RqMBUf9jNB47pPtl9ttL4zpyJ3WNvDGN+EcaTOpXPZZSK6T7OZrfs2zohuYa5zou5B6MxHC5S7zP2upjV/I8WQZrHJe2PQ6NO4Bcq37Aex27uHWQnLtyU95T01HDj2fdAc0zB7wcisDHLuv2DH9wbjveJlxAJ8ge5a8fY8VjSXMI4hX3h6X/TUDnC4z0Xc2dtN7G/E4YSN2NJLiM3mn7VWRsSlB3BdSubOPrXQnpU1oh2Z1xJa2UyQXFziXkiW7M4L6MCvzrsvabYT2unUaB0gRU1xr5L7X0S2iY0KZM5Urfh4KjvoiKAiIoCIiAiIqIREVEoiLkEREBERAREQeZ6Zbfh2aGWODnPe0loa4NIqACTOYE8gbivlnR/ZwixN94JDazNZnCa9J+KLibQxgHyg/qJoJ1rKSvsyziHDa2WFeJvXHl165+PXw49tdraENouC6NmauU19V0LI9Yf638+Os2GsT4IJnKquIiOcvb48f61jZwSCRUTl2iXPFa9ssDXiRC3t5UiPU07jxG0ujIJLhfoJLkWvYkmVob+3sX0GO4FaMWEDhNc58mo6vjzXycwdw6hfRegHSRzHthO+BxlU3E4gSuXmOk+zdx++BR3JW9+GzN+1sY4TvNRSnkcQtuNe2evn7z66sfdQiBF28xERRRERQFClQqCJJEEoiKAiIgIiICIiqPmHTaCHW44yaw3k3g912Ck/COC3+ksIOtzv0sHc0n1URYFFn8v1r8N5HPYMl0rIxa8KAunZ2AYrN/Wm34zCHRSGlZg6iUXp8cdYgyaxxYclstcBiqviMPzBL+LK5LwtdwXSjNbmFz47CCvN6SuXtqzCIyRv+ixfhhYZW1zj8kN57SWt76+a6MdtDwW7+G9mlFtL5XBjQf1Ek/2havDfnGT/wCifevoKqiLQyiIigIiIIUooQERFRKIi5BERAREQERau0La2E0FwnvODRhUgmp7Crbz7SS28jy/SCHK2tODmNPdvA+QWhte1mEwbom4mQyGq6u2LQyLEs72kbw9o1zSRvAbsxMZTBrqvObetQB0AXjqxoxL+OJE9u472/Wc9Fo2raNpY68tlkadyqyO+M9zWEkgF262lBm68nQZrmGM+M9kMMLXuu958rpzJLjOmimc1dakehsW3o4Mi4kYTXahbdcWzkvDWWI9ry1wNL5iuS9hs3ZxiM38O5ee8yV6Y1bGja9txC503SGElwn22K40cZ5zVdqte17hKgnwktY2Z7GMiuaS0v3cZ0E6NmPE1Xec/HnrV+u7YvaXuidy7djt75hrjvNuniOC8fBeYjHxBDk2HugvZvMdM4bu8Wul6rd2RaXkiZnr9RgVNZv9dY1L+PZxGUdoCu9+HsDdgxH9eIe5rG+pK4zDvQ3k9Q+AXpthvh2ezsaXAkt9o6RHu7w3iXVoAJDWS68Vk+ufNLfjvIqQIzXsa9pm1wDgcwRMFXXuzCIiAiIgKFKhBKKEQSiIoCIiAiIrAXn+moP8OAL/AGjJaETI8l6Bc3pDA34Dvyyd/Ka+E1zudzXWLzUrxdlM3hxwDvGiwW6yb5qFOy2OD3k4NLe2YPp4rcN6yW8kbpPteTi7Oex++3ea4XFsxTsWJsCJvlzGAPPzSINb6k+i96yGHC5T/DtGAXU25uI8fD2OWtm4+8b5CQlwXrtlQQyz0FPstG0necABSd671mhgQ5aLjVunpJMx5K27HD584g+i89abNGhTYWtcw1kWiuU6VwXtoh3XTw8lu+xa8VAKePdk4nkxLevnlkY9wLGsk0mcg0NbPPjqvU7O2W1jAC0T4LtNsjWijQOxYIzpJvfwxnjV3ZNePyu8lyrTHLobmMO60gAyxunPsXVY74uC4+xdlOdGdDJ+bcJvo4391Vc/ZC3lr6pYobWw2NHwhrQOAaAFlUNaAABcKDgFK2z8fOEREBERBCIiAiIglERQEREBERWAsdoh7zHN6zS3vElkRB4GHC3HVmHEODuy7gVULs7Q2RF33PG6W+86c5GUiZSzXFcZLH5M2Ru8e5b8bcOJRVixZ0Wk6NILCy1GfmvLPePStbaG0nw3hrWBzRUgGT+LQaO4TC6TtsSbMGm7Of2zWjamTquY6yvJ07V3J1LeNyxdIYzn7pgFrDP34hALst1owXqWSElwbHYxQuvF1B5rfjWotpeEvP4OhEiLRjvWFtqnisb4y89dr0zGSGZTK7PR6wDfDx8IBcc3PPuz4SNOC5VisT402MIBkTMzlSV8szTtXqdjWKKyZiFt0gGkntJ7Fpxm9jN5dSSzv11ERFpYxERAREQFClFQREQERFyCIiAiIgIiKgvDbXsphvc3CdOBqF7lcfpJZg5m/i0gcQcO9efkz7Zenj166eIiVoufanxJ/wCkxrpX7zi3uIBW9aaXJAfIaLNP8W2/5fjVgC0PkHPYw5Bpd/UStsWC0y3RHZdOcjPy9Vkc8SumtYxQrNT/AEck/UvbaWU9tCiUuIcP6mzWkyPaQ/8A1ITWsOLX73hJdWDHb1ZaqY0akpLn2nfxbnv41g4YKzHTWnEeQVuWIy94q5z2prXrHuOjNl3WF5+ag4Ccz3+S7ZWvYBKFD/S3xAK2VszOR8/V7eqoiLpBERQERFQREQEREBERcgiIgIiICIioLw3SPpYx0c2JjTMfG80kWt3wG8aVXt4jpAr5X07svsrdAtAEhEG679TQWzPFpH8qmvx1n9jM54dx81QiS0or8Qph23B/f9VlvNRsncutZmtN62S1gpILkCLkVR9pXEzY6upXYiQ2SmFzY7wLlqxLac1oWnaAGpySYtp7yRuPeLyZc4K9njbxGS47XPeZu7BgunZvdkvXsnyOJLq9r3vQa3OiQojXGfs40Rg/TRwHZvL0y8X+HLpwYzpfFHefT0XtFoz+Mev0REVQREVBERAREQQiIglERcgiIgIigoJRQXLFEceeKoiO6dy8P+Jtic+zNe3/AGnteQOrVpPZvT7F7Xn9+4rWtlmbEY+G8Ta9pa4ZtcJHwJSq+RWK1bzRO9ZXtBWpa9nvssd8F4Pun3SfnZ8ru6/UFbLDMLHvPK2Y17Rjc1wuJC14sd4+bwH0WyXFJtN6ktjq5lc+b3XuMtKLYgWYZLLTBZoQXV05zmM0GEAlpibrSclmbRcq370Z7YTKueQ1vE4nQX8AVzme1emtTOXv/wAMIbhYQ51N98Rw4b7hPwK9f7Uh0jcbuOOKw7PsTYMJkJgk1jQ0DRoAWS0s90HqmfZitkfPrZBUrEcCObisgKqJRCoVEqERAQooRRERRVkRFHIiguVZ688+SvBYuVXJTTnkKBzTXhxQOfH91jiXT7e4fUq5ux5B+qgjTH1P0QQ4U55xWPnsP2WQ3c6fQqjh4fsivK9ONh+2hb7Gj2rJlsqFwHxs1neNQM189sdoBkvtjm0/c6H0Xyvphsb+HtBewShxJuaBc19N9ulTMfqlgvLyZ+devi1y8axYCsD4CmA+iykrP+Nf6xQoMlsNhAVUNJSISpaScYbTFAEgun0AsHtLQ6MboY3W/rfSfY2f8y4doaTRe42BFbYbGx7mbzoh3924kGRmaEyDQ0XYr18U+s/m1ePdO57yjmzBGi5ew9tQrUwuZRzZB7De0+oOBXWHPctLOq0Ulfd98NUaSDzl9ka28X3+QR2cuaHLVEXnz2KEZrogpz9tEBFIUSQQiSRFEREVJKhzli3pu0F3ZerA15zCOU73DmvoFBfqOQNdUN3Z6BJ6jlw1VE72vln9lUPGflkT6q47OZqhBl+/VQWnz3BUdwPJOasZz7/Nuqq465ZZlQWLeeP/ANLGfv5n6K+9Ks+3u+hXm9vbRc8ezh0b8zpyLgCybRQ0kb0HC290le+IYcI/6QpMTm8ycC6bflm0SC7VlYy3WUscffYQJm8OABa7hukDvXnm7ILj8IvAxPzPGS3dkiLZ6tAAMt5pPuulDmAQGZg96lnVzefXGds0tJpKRII1F4WRliXtHWaHaJub7j6TGE5TyqLqrmRrIWHdIkQse8az/wAbseTOv+uCbGoNjXbEJZLNZS926BxOAGZXnO28jq65HL2ZsH2rwDRgq4y/p4lV6X2pkaIxkNwLGNDZiUt4785aCgXf2rFDG+wg3zbvOmbi4AiYBmTMzXGhWFwIp1evm9bsY9Z/6w+TftXC2NbHWeIIjHAy+JsxJzd1hLTXTwX1ux2lsRoewzaeSDqF8/Zs5xF14/N/xj6L1ezXuYLqVpOl+spXrpzHa58kcKc6/RQDPy8JZqZ+nkqiGnTmZVhUdyoO3x0+qiE/CfMgguBzzwUgo7t8c/uq9/MxmguqTUh3PPFY3FBkRYZjLwRF6hpz4aXI4y5+n6cFUc8Kd+ClxOFTz6tN2aqLMN4lzRXIrcL/APLgsAoc+aU4SWccOd7QoIaTT75O0Vzj2+QVA0Uvwz11VCNMDgOqMygzbugx8xooePMf3LHOt2fVzCtPQXjEdZQcfa8Vzhug7omJ3TcCXUMzTgudZ7LNt5NMD/4/yDRegMCZnIfL5u0VmQbuzM/KQg5jLKOqTUmoODmux4lWNib1JXXboxc3PVdJ0O+ueA6ozR7QMf7esPqqPPRGPYQ9oIIri6c2UmATi1bf8cyIN14kZhocA6jiAa0oNbuC6Psh1ssW4OIy1WIWNouIwJnW4SuB/KFLOupbHNdZSX7mPhLPgs1oishs9mwzcaEgE9WZJAvqrxbO5rJMk1pDjKpcGkTAErhPCaobE7xODus05rjGM5vV35NX40oFkBrI3473/JqVtQbIKTZP4cs3ZuW2yBK8yrkB/uazW21oEveyxb1jovR5uWyxtABDJUGA6svlOq3GMpj/AFZHMaLK1lL8BkcG5LOyGZ/Y5kZ6qKtDpnicdDkthvPesTGmWHdpx0WTnwmgq065Zc4KkQkcnL7LJOXj9VWM2fJ1yVFwZjv9foscU0pPk/dUgRBcT39ufFWjPu5wBUCfPfgeCobjp4hWfKWVRpw8VVn7DTh3qiN46osW7+bwRUXN3jPL6Yq5PZ4aynxGGaxC7T6/bDVS1xpnKnZ9wVAOnOVOBF+S2GHXLLM6LXijM88MaHwWeGTIfX9SKs3CuWWRVXSrXPLqhXrzPqo6de3PRERK+ueWmigjU3/5aK1Z9+eYVpeY81Bia0a4dbrFSGilMvI5rI0enmdVjPHy6pQSW6Dw6oRwPPEaKTjfjnkFYt57VRQA8zxdwWGMJ0lfLzP1VydOrhqcljs7Jmf6bwdDigMhndAlTdlKQn8N16l8IdXPAZt1WUC6uWXVKh7h1s8sgVBjDJXDPLrBZJHxz/NwUulWuePAqCRnnicwVRUMpdhp1fssjW6Z5ZgqGyz8dSFYupfzL7KBIZeWZClvDAc04KHOGeeIzBUjjp4kIJcOOGfBQOGXl9laevlxVCNc8s5+qDWeCCDwzHV4q5cKdnlpwxS0MEjTO7gclhY7XvnmQVRl37hx+5n2+CMPfjzj91RhOc6D608QoDvLjPj3hEYpMy/pUq24NO77oqEP4Tw9FkZ8Te3zciKKpnz8pWxA+EcPQoiishx5+UKImPb6IiqK/wDt5hRDvPOJREBmH/X1WYXc5Iigh318wh9R5oiDXbh2eRUQ7/5fREVGxDw4D1Uu+vkiKC2fOCqce30REFm385pz4FEQOfAKw570RBH28imfOChEGGPj2+RWtEuPb/kiKopC+E84hMv0+oREGgiIqP/Z"></img>
              <h3>vikas </h3>
              <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>

                <i class="fas fa-star"></i>
                <p>The instructor was very knowledgeable and provided live project</p>
                <p>cases.making the sessions more enjoyable.The topics were made</p>
                <p>easy-to-understand with real-life examples.</p>
                {/* <p></p>
                <p></p> */}
                

              
            </div>
          </div>
        </div>
        </div>
        </div>

    )
}
export default Machin;