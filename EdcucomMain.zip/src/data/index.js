const employeesData = [
  {
    id: 1,
    firstName: 'Avinash',
    lastName: 'Reddy',
    email: 'Avinash@example.com',
    password:'Avinash',
    salary: '79000',
    isLoggedIn: 'false',
    date: '2019-05-01',
    
  },
  {
    id: 2,
    firstName: 'Muni',
    lastName: 'Sekhar',
    email: 'Muni@example.com',
    password:'Muni',
    salary: '79000',
    isLoggedIn: 'false',
    date: '2019-05-01',
    
  },
  {
    id: 3,
    firstName: 'Venu',
    lastName: 'K',
    email: 'Venu@example.com',
    password:'Venu',
    salary: '56000',
    isLoggedIn: 'false',
    date: '2019-05-03'
  },
  
  {
    id: 4,
    firstName: 'Dhanush',
    lastName: 'K',
    email: 'dhanush@example.com',
    password:'Dhanu',
    salary: '79000',
    isLoggedIn: 'false',
    date: '2019-05-01'
  },
  {
    id: 5,
    firstName: 'Sanjay',
    lastName: 'LP',
    email: 'sanjay@example.com',
    password:'sanjay',
    salary: '65000',
    isLoggedIn: 'false',
    date: '2019-06-13'
  },
  {
    id: 6,
    firstName: 'Rajesh',
    lastName: 'M',
    email: 'rajesh@example.com',
    password:'rajesh',
    salary: '120000',
    isLoggedIn: 'false',
    date: '2019-07-30'
  },
  {
    id: 7,
    firstName: 'Kaveri',
    lastName: 'G',
    email: 'kaveri@example.com',
    password:'kaveri',
    salary: '90000',
    isLoggedIn: 'false',
    date: '2019-08-15'
  },
  {
    id: 8,
    firstName: 'Vinay',
    lastName: 'G',
    email: 'Vinay@example.com',
    password:'Vinay',
    salary: '60000',
    isLoggedIn: 'false',
    date: '2019-10-10'
    
  },
  {
    id: 9,
    firstName: 'Prashanth',
    lastName: 'S',
    email: 'Prashant@example.com',
    password:'Prashant',
    salary: '71000',
    isLoggedIn: 'false',
    date: '2019-10-15'
    
  },
  {
    id: 10,
    firstName: 'Gowtham',
    lastName: 'K',
    email: 'Gowtham@example.com',
    password:'gowtham',
    salary: '110000',
    isLoggedIn: 'false',
    date: '2020-01-15'
  }
];

export default { employeesData };
